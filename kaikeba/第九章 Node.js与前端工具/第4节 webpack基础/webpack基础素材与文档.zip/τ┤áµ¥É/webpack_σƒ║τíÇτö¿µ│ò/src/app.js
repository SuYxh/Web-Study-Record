import "./css/1.css";
import "./css/2.less";
let app = require("./work");