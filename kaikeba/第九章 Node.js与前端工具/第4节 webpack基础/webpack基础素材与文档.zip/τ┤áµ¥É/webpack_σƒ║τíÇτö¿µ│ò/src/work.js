document.write('我是铁蛋儿1')
let age = 18
let getShuai = () => {
    return '铁蛋儿'
}