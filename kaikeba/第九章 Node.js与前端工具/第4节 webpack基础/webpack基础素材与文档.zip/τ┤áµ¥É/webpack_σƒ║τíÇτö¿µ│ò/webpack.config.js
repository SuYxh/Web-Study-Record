const ph = require("path");
const HtmlWebpackPlugin = require("html-webpack-plugin");
module.exports = {
  mode: "development",
  // 配置loader
  module: {
    rules: [
      {
        // 处理cssloader
        test: /\.css$/, // 正则表达式匹配css文件
        // 遇到了css文件就交给如果下的loader处理
        use: ["style-loader", "css-loader"],
      },
      {
        // 处理图片的loader
        test: /\.(png|jpg|gif)$/i, // 正则匹配图片
        use: [
          {
            loader: "url-loader",
            options: {
              limit: 8192,
              outputPath: "image",
            },
          },
        ],
      },
      // less 相关的loader
      {
        test: /\.less$/,
        use: ["style-loader", "css-loader", "less-loader"],
      },
      // 处理Es6 babel-loader
      {
        test: /\.js$/,
        exclude: /node_modules/,
        use: "babel-loader",
      },
    ],
  },
  // 配置webpack-dev-server 配置段
  devServer: {
    host: "127.0.0.1", // 主机域名地址
    port: "12345",
    open: true, // 自动开启浏览器
    compress: true, // 对网络请求文件进行压缩处理
  },
  entry: ph.resolve("./src/app.js"), // 出口文件
  output: {
    // 都是绝对路劲
    path: ph.resolve("./dist"), // 配置出口目录
    filename: "main.js", // 出口文件名
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: ph.resolve("./index.html"),
    }),
  ],
};
