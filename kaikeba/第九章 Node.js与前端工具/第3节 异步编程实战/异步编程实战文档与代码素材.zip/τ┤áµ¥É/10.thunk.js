let x = 1

function f(num) {
    return 6 * 2
}
f(1 + 5)