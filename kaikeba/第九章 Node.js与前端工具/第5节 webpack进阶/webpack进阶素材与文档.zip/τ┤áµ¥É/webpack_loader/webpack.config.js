const path = require('path')
module.exports = {
    mode: 'development',
    entry: {
        main: './src/index.js'
    },
    output: {
        path: path.resolve(__dirname, 'dist'),
        filename: 'bundle.js'
    },
    // 加载loader 查找方式
    resolveLoader: {
        modules: ['node_modules', './']
    },
    module: {
        rules: [{
            test: /\.js$/,
            use: [{
                loader: 'syncLoader',
                options: {
                    message: '小白龙'
                }
            }, {
                loader: 'asyncLoader'
            }]
        }]
    }
}