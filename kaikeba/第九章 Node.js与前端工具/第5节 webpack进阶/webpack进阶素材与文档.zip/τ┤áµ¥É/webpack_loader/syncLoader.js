const { getOptions } = require("loader-utils");
module.exports = function (source) {
  // 必须有返回值 而且必须是buffter或者是字符串类型
  //   console.log(this.query.message);
  console.log(getOptions(this).message);
  //   return source.replace("word", getOptions(this).message);
  // this.callback的写法  他可以返回多个参数
  let res = source.replace("word", getOptions(this).message);
  this.callback(null, res);
};
