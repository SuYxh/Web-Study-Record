const {
  getOptions
} = require("loader-utils");
module.exports = function (source) {
  // 必须有返回值 而且必须是buffter或者是字符串类型
  let asyncCallback = this.async()
  let res = source.replace("hello", '铁蛋儿');
  setTimeout(() => {
    asyncCallback(null, res);
  }, 1000)

};