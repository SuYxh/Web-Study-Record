class DemoWebpackPlugin {
  constructor() {
    console.log("初始化");
  }
  //  compiler 就是webpack实例
  apply(compiler) {
    // console.log(compiler);
    compiler.hooks.compile.tap("aaa", (compilation) => {
      console.log(compilation);
    });
    compiler.hooks.emit.tapAsync("bbb", (compilation, fn) => {
      compilation.assets["index.md"] = {
        source: function () {
          return "我是小白龙";
        },
        size: function () {
          return 25;
        },
      };
      fn();
    });
  }
}
module.exports = DemoWebpackPlugin;
