import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)
Vue.config.productionTip = false
import Applist from './list.vue'
import Foo from './foo.vue'
import Bar from './bar.vue'
import Add from './add.vue'
import Edit from './edit.vue'
const router = new VueRouter({
  linkActiveClass: "active",
  routes: [{
    path: '/',
    redirect: '/heroes'

  }, {
    path: '/heroes',
    component: Applist,

  }, {
    path: '/foo',
    component: Foo
  }, {
    path: '/bar',
    component: Bar
  }, {
    path: '/add',
    component: Add
  }, {
    path: '/edit/:id',
    component: Edit,
    keepAlive: false
  }]
})
export default router
