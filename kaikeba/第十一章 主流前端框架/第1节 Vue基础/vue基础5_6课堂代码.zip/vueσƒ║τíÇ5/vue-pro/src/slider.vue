<template>
  <ul class="nav nav-sidebar">
    <router-link tag="li" to="/heroes">
      <a href="#">人物列表</a>
    </router-link>
    <router-link tag="li" to="/foo">
      <a href="#">任务列表</a>
    </router-link>
    <router-link tag="li" to="/bar">
      <a href="#">积分列表</a>
    </router-link>
  </ul>
</template>

<script>
export default {};
</script>

<style></style>
