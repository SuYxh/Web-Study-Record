const defaultState = {
    inputValue: '铁蛋儿很帅',
    list: [1, 2]
}

export default (state = defaultState, action) => {
    return state
}