import React from "react";
import ReactDOM from "react-dom";
const app = <h1>hello word </h1>;

ReactDOM.render(app, document.getElementById("root"));
