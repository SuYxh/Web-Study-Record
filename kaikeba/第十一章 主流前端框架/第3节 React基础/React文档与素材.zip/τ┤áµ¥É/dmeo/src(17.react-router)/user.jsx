import React, { Component } from "react";
class User extends Component {
  state = {};
  render() {
    return <div>我是User组件</div>;
  }
}

export default User;
