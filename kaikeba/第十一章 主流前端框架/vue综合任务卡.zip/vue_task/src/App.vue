<template>
  <a-config-provider >
    <div id="app">
      <router-view/>
    </div>
  </a-config-provider>
</template>

<script>

export default {
  data () {
    return {
    }
  },
}
</script>
