## Vue综合小案例

> 需要本地开启mongodb服务



### 案例展示

![](http://qn.huat.xyz/content/20201017160545.png)



![](http://qn.huat.xyz/content/20201017162024.png)



### 技术栈

1、vue + Ant Design 

2、node + express 5.0 版

3、mongodb - mongoose



### 功能

1、登陆  --  路由守卫 、 token认证

2、注册

3、文件上传 — 阿里云OSS

4、增删改查

5、模糊查询

6、数据初始化

7、富文本 【待做】



存在的问题：如何部署？nodejs程序使用pm2部署后，但是无法访问服务器的数据库