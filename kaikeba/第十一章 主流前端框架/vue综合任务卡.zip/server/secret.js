module.exports = {
    region: 'oss-cn-beijing',
    accessKeyId: 'LTAI4G3K79vgc3vVoqSsyX5R',
    accessKeySecret: 'Wxl5fWRcwVIMowOxEAJNx8Qxf2wgl7',
    bucket: 'node-vue-repository'
}