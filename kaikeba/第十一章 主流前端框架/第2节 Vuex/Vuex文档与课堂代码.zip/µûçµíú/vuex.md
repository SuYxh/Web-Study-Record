## Vuex

> vuex 是一个专门为vue.js应用程序开发的**状态管理模式**。
>
> 这个状态我们可以理解为在data中的属性，需要共享给其他组件使用的部分。
>
> 也就是说，是我们需要共享的data，使用vuex进行统一集中式的管理。

官网:https://vuex.vuejs.org/zh/guide/

**Vuex中，有默认的五种基本的对象：**

- state：存储状态（变量）

  > 虽然state和data有很多相似之处,但state在使用的时候一般被挂载到子组件的computed计算属性上,这样有利于state的值发生改变的时候及时响应给子组件.如果你用data去接收store.state,当然可以接收到值,但由于这只是一个简单的赋值操作,因state中的状态改变的时候不能被vue中的data监听到,当然可以通过watch监听$store去解决这个问题,那你就一个妥妥的杠精

  - mapState

- mutation：修改状态，并且是同步的。在组件中使用$store.commit("handle'',params)。这个和我们组件中的自定义事件类似。

  - mapMutations

- action：异步操作。在组件中使用是$store.dispath("handle'',params)

  - mapActions 

- getter：对数据获取之前的再次编译，可以理解为state的计算属性。我们在组件中使用 $store.getters.fn

  - mapGetters

- module：store的子模块，为了开发大型项目，方便状态管理而使用的。

