import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
const state = {
  count: 0,
  name: '铁蛋儿',
  age: 18
}
const mutations = {
  mutationsAddCount(state, n = 0) {
    return (state.count += n)
  },
  mutationsReduceCount(state, n = 0) {
    return (state.count -= n)
  }
}
const actions = {
  actionAddCount(context, n = 0) {
    setTimeout(() => {
      context.commit('mutationsAddCount', n)
    }, 2000)
  },
  actionReduceCount(context, n = 0) {
    setTimeout(() => {
      context.commit('mutationsReduceCount', n)
    }, 2000)
  }
}
const getters = {
  todoCount(state) {
    return state.count + 100
  }
}
export default new Vuex.Store({
  state,
  mutations,
  actions,
  getters
})
