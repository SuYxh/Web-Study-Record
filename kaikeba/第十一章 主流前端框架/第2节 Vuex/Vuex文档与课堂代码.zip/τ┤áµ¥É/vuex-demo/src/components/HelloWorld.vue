<template>
  <h1>
    <!-- 使用state -->
    {{$store.state.count}}
    data:{{dataCount}}
    comCount:{{123}}
    <div>第一种:{{count}}</div>
    <div>第二种:{{name}}</div>
    <div>第三种:{{age}}</div>
    <div>
      <button @click="add(10)">加</button>
      <button @click="reduce(10)">减</button>
    </div>
    <div>
      <h2>{{addcount}}</h2>
    </div>
  </h1>
</template>

<script>
import { mapState, mapMutations, mapActions, mapGetters } from "vuex";
export default {
  name: "HelloWorld",
  data() {
    return {
      // data接收state 不是触发监听
      dataCount: this.$store.state.count,
    };
  },
  methods: {
    // handleAddClick(n) {
    //   this.$store.commit("mutationsAddCount", n);
    // },
    // handleReduceClick(n) {
    //   this.$store.commit("mutationsReduceCount", n);
    // },
    // handleAddClick(n) {
    //   this.$store.dispatch("actionAddCount", n);
    // },
    // handleReduceClick(n) {
    //   this.$store.dispatch("actionReduceCount", n);
    // },
    // 数组的形式
    // ...mapMutations([`mutationsAddCount`, `mutationsReduceCount`]),
    // 对象的写法
    // ...mapMutations({
    //   add: `mutationsAddCount`,
    //   reduce: `mutationsReduceCount`,
    // }),
    // ...mapActions([`actionAddCount`, `actionReduceCount`]),
    ...mapActions({
      add: `actionAddCount`,
      reduce: `actionReduceCount`,
    }),
  },
  computed: mapState({
    count: "count",
    name: (state) => state.name,
    age: function (state) {
      return 2 + state.age;
    },
    // ...mapGetters([`todoCount`]),
    ...mapGetters({
      addcount: `todoCount`,
    }),
  }),
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
</style>
