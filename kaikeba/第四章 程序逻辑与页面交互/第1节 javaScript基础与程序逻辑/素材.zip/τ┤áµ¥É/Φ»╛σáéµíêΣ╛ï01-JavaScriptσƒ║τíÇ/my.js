var name = "zhangsan";

console.log("Hello "+name);